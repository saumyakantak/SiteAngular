const Sequelize = require('sequelize');

const sequelize = require('../util/database');

const Product = sequelize.define('product', {
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    allowNull: false,
    primaryKey: true
  },
  title: Sequelize.STRING,
  price: {
    type: Sequelize.DOUBLE,
    allowNull: false
  },
  categoryType:{
    type: Sequelize.STRING,
    allowNull:false
  },
  // categoryId: {
  //   type: Sequelize.INTEGER,
  //   allowNull: false,
  //   references:{
  //     model: 'category',
  //     key:'id'
  //   }
  // },
  imageUrl: {
    type: Sequelize.STRING,
    allowNull: false
  },
  description: {
    type: Sequelize.STRING,
    allowNull: false
  }
});

module.exports = Product;
