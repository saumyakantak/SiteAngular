export interface ItemDetail {
    id:number
}
