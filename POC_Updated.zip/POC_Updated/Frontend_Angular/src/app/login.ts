export class Login {
    constructor(
        public token: string,
        public userId: string
      ) {  }
}
